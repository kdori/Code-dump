package mozimusor;

import java.util.Calendar;

public class moziMusor {
     
     private String cim;
     private Integer hossz;
     private Integer korhatar;
     private String premier;
     private String ora;
     private String knap;
     private String znap;
     private String terem;
     private String tipus;
     
     public moziMusor(){}
     
     public moziMusor(String cim, Integer hossz, Integer korhatar, String premier, String ora,String knap,String znap,String terem,String tipus){
         this.cim = cim;
         this.hossz = hossz;
         this.knap = knap;
         this.korhatar = korhatar;
         this.ora =  ora;
         this.premier = premier;
         this.terem = terem;
         this.tipus = tipus;
         this.znap = znap;
     }
     
     public moziMusor(String cim, Integer hossz, Integer korhatar, String premier){
         this.cim = cim;
         this.hossz = hossz;
         this.korhatar = korhatar;
         this.premier = premier;
     }
     
     public moziMusor(String cim, String ora,String knap,String znap,String terem,String tipus){
          this.cim = cim;
          this.ora = ora;
          this.knap = knap;
          this.znap = znap; 
          this.terem = terem;
          this.tipus = tipus;
     }

    public String getCim() {
        return cim;
    }

    public void setCim(String cim) {
        this.cim = cim;
    }

    public Integer getHossz() {
        return hossz;
    }

    public void setHossz(Integer hossz) {
        this.hossz = hossz;
    }

    public Integer getKorhatar() {
        return korhatar;
    }

    public void setKorhatar(Integer korhatar) {
        this.korhatar = korhatar;
    }

    public String getPremier() {
        return premier;
    }

    public void setPremier(String premier) {
        this.premier = premier;
    }

    public String getOra() {
        return ora;
    }

    public void setOra(String ora) {
        this.ora = ora;
    }

    public String getKnap() {
        return knap;
    }

    public void setKnap(String knap) {
        this.knap = knap;
    }

    public String getZnap() {
        return znap;
    }

    public void setZnap(String znap) {
        this.znap = znap;
    }

    public String getTerem() {
        return terem;
    }

    public void setTerem(String terem) {
        this.terem = terem;
    }

    public String getTipus() {
        return tipus;
    }

    public void setTipus(String tipus) {
        this.tipus = tipus;
    }
     
    public Calendar DateMaker(String bd){
        String bev = Character.toString(bd.charAt(0)) + Character.toString(bd.charAt(1)) + Character.toString(bd.charAt(2)) + Character.toString(bd.charAt(3));
        String bhn = Character.toString(bd.charAt(5)) + Character.toString(bd.charAt(6));
        String bn = Character.toString(bd.charAt(8)) + Character.toString(bd.charAt(9));
        Calendar b = Calendar.getInstance();
        b.set(Integer.parseInt(bev), Integer.parseInt(bhn) - 1, Integer.parseInt(bn), 00, 00, 00);
        return b;
    }
    
    public String DatetoString(Calendar v){
        String vt = String.valueOf(v.get(Calendar.YEAR));
        Integer vev = Integer.parseInt(vt);
        Integer vhn = v.get(Calendar.MONTH) + 1;
        Integer vn = v.get(Calendar.DAY_OF_YEAR);
        String c = vev.toString() + "." + vhn.toString() + "." + vn.toString();
        return c;
    }
    
}
    
    
            
     


